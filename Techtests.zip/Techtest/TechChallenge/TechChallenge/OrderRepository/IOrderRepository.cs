﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TechChallenge.OrderRepository
{
    public interface IOrderRepository
    {
        XDocument GetXml(IFormFile path);
    }
}
