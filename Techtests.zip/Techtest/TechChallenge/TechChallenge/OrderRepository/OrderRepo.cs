﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using TechChallenge.Common;
using TechChallenge.OrderModel;

namespace TechChallenge.OrderRepository
{
    public class OrderRepo : IOrderRepository
    {
        ILogger _logger;
        XDocument result = null;
     
        public XDocument GetXml(IFormFile path)
        {
            try
            {
                var sr = new StreamReader(path.OpenReadStream());
                var fileContent = sr.ReadToEnd();
                string[] val = fileContent.Split('\n');
                sr.Close();

                result = XmlBuilder.PrepareOrderXml(Mapper.MapOrders(val));
            }catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                throw ex;
            }
            return result;
        }
    }
}
