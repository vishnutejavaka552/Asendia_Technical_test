﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TechChallenge.OrderRepository;

namespace TechChallenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        IOrderRepository _orderRepository;
        ILogger _logger;
        XDocument result = null;

        public OrderController(IOrderRepository orderRepository, ILogger logger)
        {
            _orderRepository = orderRepository;
            _logger = logger;

           
        }
        [HttpPatch("getXML")]
        public IActionResult Getdata(IFormFile csvFilePath)
        {
            if (csvFilePath.FileName.Contains(".csv"))
            {
                try
                {
                    result = _orderRepository.GetXml(csvFilePath);
                    result.ToString();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.ToString());
                    return NotFound();
                }
                return Ok(result);
            }
            else
            {
                _logger.LogError("Invalied file type");
                return BadRequest("File should be in .CSV fromat");
            }
        }
    }
}
