﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TechChallenge.OrderModel
{
    public class Order
    {
        public string Order_No { get; set; }
        public string Consignment_No { get; set; }
        public string Parcel_Code { get; set; }
        public string Consignee_Name { get; set; }
        public string Address_1 { get; set; }
        public string Address_2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country_Code { get; set; }
        public string Item_Quantity { get; set; }
        public decimal Item_Value { get; set; }
        public decimal Item_Weight { get; set; }
        public string Item_Description { get; set; }
        public string Item_Currency { get; set; }
    }
}
