﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TechChallenge.Common
{
    public static class COps
    {
        public static decimal ConvertTodecimal(string val)
        {
            return decimal.Parse(val);
        }
        public static string Setcurrency(string val)
        {
            return val == "" ? "GBP" : val;
        }

    }
}
