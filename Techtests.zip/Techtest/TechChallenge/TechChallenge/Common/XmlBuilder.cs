﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using TechChallenge.OrderModel;

namespace TechChallenge.Common
{
    public static class XmlBuilder
    {
        public static XDocument PrepareOrderXml(List<Order> orders)
        {
            var order = new XElement("Orders", from a in orders select new XElement("Order", a.Order_No));
            order.Add(new XElement("TotalWeight", orders.Sum(o => o.Item_Weight)));
            order.Add(new XElement("TotalValue", orders.Sum(o => o.Item_Value)+"GBP"));
            XElement srcTree = new XElement("Root",
                new XElement(order),
            new XElement("Consignments", from a in orders select new XElement("Consignment", a.Consignment_No + ":" + a.Consignee_Name)),
            new XElement("Parcels", from a in orders select new XElement("Parcel", a.Parcel_Code)),
            new XElement("ParcelItems", from a in orders select new XElement("ParcelItem", a.Item_Description)));
            return new XDocument(srcTree);
        }
    }
}
