﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TechChallenge.OrderModel;

namespace TechChallenge.Common
{
    public static class Mapper
    {

        public static List<Order> MapOrders(string[] val)
        {
            List<Order> str = new List<Order>();

            for (int i = 1; i < val.Length; i++)
            {
                string val2 = val[i];
                if (val[i] != "")
                {
                    val2 = val[i].Replace("\r", "");
                    string[] val3 = val[i].Split(',');

                    Order order = new Order()
                    {
                        Order_No = val3[0],
                        Consignment_No = val3[1],
                        Parcel_Code = val3[2],
                        Consignee_Name = val3[3],
                        Address_1 = val3[4],
                        Address_2 = val3[5],
                        City = val3[6],
                        State = val3[7],
                        Country_Code = val3[8],
                        Item_Quantity = val3[9],
                        Item_Value = COps.ConvertTodecimal(val3[10]),
                        Item_Weight = COps.ConvertTodecimal(val3[11]),
                        Item_Description = val3[12],
                        Item_Currency = COps.Setcurrency(val3[13]),
                    };
                    str.Add(order);
                }
            }

            return str;
        }
    }
}
