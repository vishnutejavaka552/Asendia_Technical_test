using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NSubstitute;
using System;
using System.IO;
using TechChallenge.Controllers;
using TechChallenge.OrderRepository;

using Xunit;

namespace TechChallengeTest
{
    public class OrderControllerTests
    {
        private OrderController _orderController;

        public OrderControllerTests()
        {
            IOrderRepository _orderepository = Substitute.For<IOrderRepository>();
            ILogger logger = Substitute.For<ILogger>();
            _orderController = new OrderController(_orderepository, logger);
        }


        [Fact]
        public void Should_return_BadReques_when_passivalidfile()
        {
            var mock = new Mock<ILogger<OrderController>>();
            ILogger<OrderController> logger = mock.Object;

            //or use this short equivalent 
            logger = Mock.Of<ILogger<OrderController>>();


            //_logger.Setup(m => m.LogError(It.IsAny<Exception>(), It.IsAny<string>()));
            //Arrange
            var fileMock = new Mock<IFormFile>();
            //Setup mock file using a memory stream
            var content = "Hello World from a Fake File";
            var fileName = "test.pdf";
            var ms = new MemoryStream();
            var writer = new StreamWriter(ms);
            writer.Write(content);
            writer.Flush();
            ms.Position = 0;
            fileMock.Setup(_ => _.OpenReadStream()).Returns(ms);
            fileMock.Setup(_ => _.FileName).Returns(fileName);
            fileMock.Setup(_ => _.Length).Returns(ms.Length);
            var file = fileMock.Object;
            //Assert

           var result= _orderController.Getdata(file);
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(400, badRequestResult.StatusCode);
            //  Assert.Equal(result, BadRequestObjectResult);
        }
      
        [Fact]
        public void Should_return_Notfound_when_passivaliddata()
        {
            var mock = new Mock<ILogger<OrderController>>();
            ILogger<OrderController> logger = mock.Object;

            //or use this short equivalent 
            logger = Mock.Of<ILogger<OrderController>>();
            //Arrange
            var fileMock = new Mock<IFormFile>();
            //Setup mock file using a memory stream
            var content = "Hello World from a Fake File";
            var fileName = "test.csv";
            var ms = new MemoryStream();
            var writer = new StreamWriter(ms);
            writer.Write(content);
            writer.Flush();
            ms.Position = 0;
            fileMock.Setup(_ => _.OpenReadStream()).Returns(ms);
            fileMock.Setup(_ => _.FileName).Returns(fileName);
            fileMock.Setup(_ => _.Length).Returns(ms.Length);
            var file = fileMock.Object;
            //Assert

            var result = _orderController.Getdata(file);

            Assert.IsType<Microsoft.AspNetCore.Mvc.NotFoundResult>(result);

        }

    }
}
