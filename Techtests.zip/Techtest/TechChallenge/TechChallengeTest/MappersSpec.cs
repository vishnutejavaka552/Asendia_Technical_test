﻿using System;
using System.Collections.Generic;
using System.Text;
using TechChallenge.Common;
using Xunit;

namespace TechChallengeTest
{
    public class MappersSpec
    {
        [Theory]
        [InlineData(new object[] { new string[] { "Order No, Consignment No, Parcel Code,Consignee Name, Address 1, Address 2, City, State, Country Code,Item Quantity, Item Value, Item Weight, Item Description,Item Currency"
            ,"ORD001,CON001,PARC002,Bob Berg,10 Baker Street,Peckham,London,,GB,2,3.4,0.3,Pencil Case,",
        "ORD001,CON001,PARC001,Bob Berg,10 Baker Street,Peckham,London,,GB,1,1.1,0.004,Pen,",
        "ORD003,CON003,PARC004,D Cameron,10 Downing St,Brixton,,London,GB,1,80,1.9,Pen,"} })]
        public void Should_return_thedata_when_stringval(string[] val) {
            var result = Mapper.MapOrders(val);
            Assert.NotNull(result);
        }
    }
}
